# HOME Client V0.1

Prototipe antarmuka Android berbasis HTML di dalam Android WebView.

## Build APK lewat GitHub Actions
1. Ekstrak ZIP dan upload semua isi folder ke repository GitHub.
2. Pastikan file `.github/workflows/build.yml` ikut ter-upload.
3. Buka tab **Actions** dan jalankan **Build HOME CLIENT APK**.
4. Setelah workflow berhasil, unduh artifact `HOME-CLIENT-V0.1-APK`.

APK debug berada di `app/build/outputs/apk/debug/app-debug.apk`.

Catatan: Versi ini masih prototipe UI. Kontrol di halaman bekerja untuk preview antarmuka, belum mengubah fitur internal Minecraft Bedrock.
